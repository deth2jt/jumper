package com.badlogic.androidgames.jumper;

public class LoadingScreen {

}
