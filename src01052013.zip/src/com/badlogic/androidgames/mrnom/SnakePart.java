package com.badlogic.androidgames.mrnom;

public class SnakePart 
{
	public int x, y;

	public SnakePart(int x, int y) 
	{
		this.x = x;
		this.y = y;
	}
}